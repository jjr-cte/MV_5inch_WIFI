@echo off

setLocal EnableDelayedExpansion
set out=.\out_img
set obj_bin=".\out_DA14531\Objects\pxr_sr_coex_ext_531_6_0_14_1114.bin"
set version=".\..\..\..\..\..\binaries\da14531\mkimage\app_version.h"
REM set version=".\..\..\..\..\..\binaries\da14531\mkimage\app_version_q.h"
REM set version=".\..\..\..\..\..\binaries\da14531\mkimage\app_version_s.h"
set mkimage=".\..\..\..\..\..\binaries\da14531\mkimage\mkimage.exe"
set name1=pxr_sr_coex_ext_531_6_0_14_1114_1.img
set name2=pxr_sr_coex_ext_531_6_0_14_1114_2.img
set name1_ota=pxr_sr_coex_ext_531_6_0_14_1114_1_ota.img
set name2_ota=pxr_sr_coex_ext_531_6_0_14_1114_2_ota.img
set multi_img_name=da14531_multi_part_proxr.img

REM "header_position must be same as PRODUCT_HEADER_OFFSET in the .\core\system\include\ota\ota_update.h"
set header_position=0xFF20
REM set header_position=0x13F20

REM "sing_fw_size must be same as (__BLE_IMG_SIZE__ / 2) in \apps\da16600\get_started\include\apps\ble_combo_features.h"
REM "For example 0x10000 -> 0x10000/2 = 0x8000 = 32kB, 0x14000 -> 0x14000/2 = 0xA000 = 40kB"
set sing_fw_size=0x8000
REM set sing_fw_size=0xA000

REM set multi_img_name=da14531_multi_part_proxr_q.img
REM set multi_img_name=da14531_multi_part_proxr_s.img

if exist %out% GOTO not_make_dir
mkdir %out%
:not_make_dir

REM "Make images for DA16600: **1, **2 and 2&1-multi images"

echo creating image '%out%\%name1%'...
%mkimage% single %obj_bin% %version% %out%\%name1%

echo creating image '%out%\%name2%'...
%mkimage% single %obj_bin% %version% %out%\%name2%

echo creating image '%out%\%name1%'...
%mkimage% single_ota %obj_bin% %version% %out%\%name1_ota%

echo creating image '%out%\%name2%'...
%mkimage% single_ota %obj_bin% %version% %out%\%name2_ota%

%mkimage% multi spi %out%\%name2% 0x20 %out%\%name1% %sing_fw_size% %header_position% %out%\%multi_img_name%

ENDLOCAL