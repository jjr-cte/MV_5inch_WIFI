#if defined (__BLE_PERIPHERAL_IMG_2__)
#define SDK_VERSION "6.0.14.1114.2.s"
#elif defined (__BLE_PERIPHERAL_IMG_3__)
#define SDK_VERSION "6.0.14.1114.2.q"
#else
#define SDK_VERSION "6.0.14.1114.2"
#endif
#define SDK_VERSION_DATE "2021-02-05 13:31 "
