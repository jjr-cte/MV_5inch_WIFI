set new-console on
